'use client';

import LinkField from "./LinkField";
import PhoneField from "./PhoneField";
import MediaSourceField from "./MediaSourceField";
import AdvancedOptions from "./AdvancedOptions";
import { typeMeta } from "./lib/qrTypes";
import type { useQrTarget } from "./lib/useQrTarget";

type Props = {
  target: ReturnType<typeof useQrTarget>;
  fgColor: string;
  bgColor: string;
  onFgChange: (color: string) => void;
  onBgChange: (color: string) => void;
  error: string;
  onBack: () => void;
  onCreate: () => void;
};

export default function StepInfo({
  target,
  fgColor,
  bgColor,
  onFgChange,
  onBgChange,
  error,
  onBack,
  onCreate,
}: Props) {
  const meta = typeMeta(target.type);

  return (
    <section>
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#001F3F] text-lg font-bold text-white">
          2
        </span>
        <div className="min-w-0">
          <h2 className="text-xl font-bold tracking-tight text-[#001F3F] sm:text-2xl">
            Entrez l&apos;information
          </h2>
          <p className="text-sm text-slate-500">
            <span className="mr-1">{meta.emoji}</span>
            {meta.ask}
          </p>
        </div>
      </div>

      <div className="mt-5 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-[0_1px_2px_rgba(16,24,40,0.04),0_16px_36px_-28px_rgba(0,31,63,0.45)]">
        {target.type === "web" && (
          <LinkField
            id="qr-web"
            label="Lien de mon site"
            icon="ri-global-line"
            placeholder="https://mon-site.com"
            hint="Commencez par https://"
            value={target.webUrl}
            onChange={target.setWebUrl}
          />
        )}

        {target.type === "payment" && (
          <LinkField
            id="qr-payment"
            label="Lien de paiement"
            icon="ri-secure-payment-line"
            placeholder="https://..."
            hint="Flooz, T-Money, Moov Money, Wave…"
            value={target.paymentUrl}
            onChange={target.setPaymentUrl}
          />
        )}

        {target.type === "online" && (
          <LinkField
            id="qr-doc"
            label="Lien de mon document"
            icon="ri-file-text-line"
            placeholder="https://docs.google.com/document/d/…"
            hint="Google Docs : Partager → Tous les utilisateurs disposant du lien."
            value={target.docUrl}
            onChange={target.setDocUrl}
          />
        )}

        {(target.type === "whatsapp" || target.type === "phone") && (
          <PhoneField
            mode={target.type}
            value={target.phone}
            onChange={target.setPhone}
          />
        )}

        {target.type === "photo" && (
          <MediaSourceField
            kind="photo"
            mode={target.photoMode}
            onModeChange={target.setPhotoMode}
            directLink={target.photoDirect}
            onDirectLinkChange={target.setPhotoDirect}
            fileName={target.photoName}
            fileLink={target.photoHosted}
            onUploaded={target.setPhoto}
            onCleared={target.clearPhoto}
          />
        )}

        {target.type === "file" && (
          <MediaSourceField
            kind="file"
            mode={target.fileMode}
            onModeChange={target.setFileMode}
            directLink={target.fileDirect}
            onDirectLinkChange={target.setFileDirect}
            fileName={target.fileName}
            fileLink={target.fileHosted}
            onUploaded={target.setFile}
            onCleared={target.clearFile}
          />
        )}

        <div className="mt-5">
          <AdvancedOptions
            value={target.value}
            fgColor={fgColor}
            bgColor={bgColor}
            onFgChange={onFgChange}
            onBgChange={onBgChange}
          />
        </div>

        {error && (
          <p className="mt-4 flex items-start gap-2 rounded-xl bg-red-50 px-3 py-2.5 text-sm font-medium text-[#E60000]">
            <i className="ri-error-warning-line mt-0.5" />
            {error}
          </p>
        )}

        <button
          type="button"
          onClick={onCreate}
          className="mt-5 flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-[#E60000] px-5 py-4 text-base font-bold text-white shadow-[0_14px_28px_-16px_rgba(230,0,0,0.9)] transition hover:bg-[#c90000] active:scale-[0.99] whitespace-nowrap"
        >
          <i className="ri-qr-code-line text-lg" />
          Créer mon QR Code
        </button>

        <button
          type="button"
          onClick={onBack}
          className="mt-3 w-full cursor-pointer py-2 text-sm font-medium text-slate-400 transition hover:text-[#001F3F] whitespace-nowrap"
        >
          ← Changer de type
        </button>
      </div>
    </section>
  );
}