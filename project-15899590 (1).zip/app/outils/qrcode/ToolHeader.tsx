import Link from "next/link";
import BrandLogo from "../../components/BrandLogo";

export default function ToolHeader() {
  return (
    <header className="border-b border-slate-200/80 bg-white">
      <div className="mx-auto flex h-16 w-full max-w-[1240px] items-center justify-between px-5 sm:px-8">
        <Link href="/" className="flex items-center gap-3">
          <BrandLogo height={30} />
          <span className="hidden rounded-md bg-gray-50 px-2 py-0.5 text-[11px] font-medium text-slate-500 sm:inline">
            Outils
          </span>
        </Link>

        <div className="flex items-center gap-4">
          <span className="hidden text-xs text-slate-400 sm:inline">
            Sans compte, 100 % en ligne
          </span>
          <Link
            href="/"
            className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:border-[#001F3F]/30 hover:text-[#001F3F] whitespace-nowrap"
          >
            <i className="ri-arrow-left-line" />
            Accueil
          </Link>
        </div>
      </div>
    </header>
  );
}