'use client';

import Link from "next/link";
import { useSearchParams } from "next/navigation";

function cleanUrl(url: string) {
  return url.split("#")[0];
}

function isImage(url: string) {
  return /\.(png|jpe?g|webp|gif|avif|bmp)(\?|$)/i.test(cleanUrl(url));
}

export default function DocumentViewer() {
  const params = useSearchParams();
  const src = (params.get("src") ?? "").trim();
  const title = (params.get("n") ?? "").trim();
  const valid = /^https?:\/\//i.test(src);
  const image = valid && isImage(src);

  if (!valid) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white px-6">
        <div className="text-center">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#E60000]/10 text-[#E60000]">
            <i className="ri-file-warning-line text-2xl" />
          </span>
          <p className="mt-4 text-base font-semibold text-[#001F3F]">
            Attestation introuvable
          </p>
          <Link
            href="/"
            className="mt-4 inline-flex cursor-pointer items-center justify-center rounded-xl bg-[#001F3F] px-4 py-2.5 text-sm font-bold text-white whitespace-nowrap"
          >
            Retour à l&apos;accueil
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[100dvh] w-screen overflow-hidden bg-white">
      {image ? (
        <img
          src={src}
          alt={title || "Attestation de formation"}
          className="block h-full w-full object-contain"
        />
      ) : (
        <iframe
          src={`${cleanUrl(src)}#view=FitH`}
          title={title || "Attestation de formation"}
          className="block h-full w-full border-0 bg-white"
        />
      )}
    </div>
  );
}