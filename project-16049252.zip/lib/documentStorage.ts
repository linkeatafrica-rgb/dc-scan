import { supabase } from "./supabaseClient";

export const DOCUMENT_BUCKET = "attestations";
export const MAX_DOCUMENT_SIZE = 10 * 1024 * 1024;

export type StoredDocument = {
  id: string;
  title: string | null;
  fileName: string;
  storagePath: string;
  publicUrl: string;
  fileSize: number | null;
  mimeType: string | null;
  createdAt: string;
};

function safeName(name: string) {
  const base = name.replace(/[^\w.\-]+/g, "-").replace(/-+/g, "-");
  return base.replace(/^-|-$/g, "") || "document";
}

export async function uploadDocument(
  file: File,
  onProgress?: (percent: number) => void
): Promise<StoredDocument> {
  const { data: sessionData, error: sessionError } = await supabase.auth.getUser();
  if (sessionError) throw new Error("session");
  const user = sessionData?.user;
  if (!user) throw new Error("session");

  if (file.size > MAX_DOCUMENT_SIZE) throw new Error("size");

  const path = `${user.id}/${Date.now()}-${safeName(file.name)}`;

  onProgress?.(15);

  const { error: uploadError } = await supabase.storage
    .from(DOCUMENT_BUCKET)
    .upload(path, file, {
      cacheControl: "31536000",
      upsert: false,
      contentType: file.type || "application/octet-stream",
    });

  if (uploadError) throw new Error("upload");

  onProgress?.(80);

  const { data: publicData } = supabase.storage.from(DOCUMENT_BUCKET).getPublicUrl(path);
  const publicUrl = publicData.publicUrl;

  const { data: row, error: rowError } = await supabase
    .from("attestation_documents")
    .insert({
      owner_id: user.id,
      file_name: file.name,
      storage_path: path,
      public_url: publicUrl,
      mime_type: file.type || null,
      file_size: file.size,
    })
    .select("*")
    .maybeSingle();

  if (rowError) {
    await supabase.storage.from(DOCUMENT_BUCKET).remove([path]);
    throw new Error("register");
  }

  onProgress?.(100);

  return {
    id: row?.id ?? path,
    title: row?.title ?? null,
    fileName: file.name,
    storagePath: path,
    publicUrl,
    fileSize: file.size,
    mimeType: file.type || null,
    createdAt: row?.created_at ?? new Date().toISOString(),
  };
}

export async function listDocuments(): Promise<StoredDocument[]> {
  const { data, error } = await supabase
    .from("attestation_documents")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) throw new Error("list");

  return (data ?? []).map((row) => ({
    id: String(row.id),
    title: (row.title as string | null) ?? null,
    fileName: String(row.file_name),
    storagePath: String(row.storage_path),
    publicUrl: String(row.public_url),
    fileSize: (row.file_size as number | null) ?? null,
    mimeType: (row.mime_type as string | null) ?? null,
    createdAt: String(row.created_at),
  }));
}

export async function deleteDocument(doc: StoredDocument): Promise<void> {
  const { error: storageError } = await supabase.storage
    .from(DOCUMENT_BUCKET)
    .remove([doc.storagePath]);
  if (storageError) throw new Error("remove-file");

  const { error: rowError } = await supabase
    .from("attestation_documents")
    .delete()
    .eq("id", doc.id);
  if (rowError) throw new Error("remove-row");
}

export function publicDownloadUrl(url: string, fileName: string) {
  const base = url.split("?")[0];
  return `${base}?download=${encodeURIComponent(fileName)}`;
}