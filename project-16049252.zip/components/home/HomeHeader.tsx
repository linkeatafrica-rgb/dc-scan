import Link from "next/link";
import BrandLogo from "../BrandLogo";

export default function HomeHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#020A14]/85 backdrop-blur-xl">
      <div className="flex h-16 w-full items-center justify-between px-5 sm:px-8">
        <Link
          href="/"
          aria-label="DC Scan, accueil"
          className="flex cursor-pointer items-center"
        >
          <BrandLogo height={32} chip />
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link
            href="/"
            className="cursor-pointer text-sm text-white transition hover:text-[#2E9BFF]"
          >
            Accueil
          </Link>
          <a
            href="#avantages"
            className="cursor-pointer text-sm text-white/60 transition hover:text-white"
          >
            Avantages
          </a>
          <a
            href="#fonctionnement"
            className="cursor-pointer text-sm text-white/60 transition hover:text-white"
          >
            Fonctionnement
          </a>
        </nav>

        <div className="flex items-center gap-3 sm:gap-4">
          <Link
            href="/login"
            className="inline-flex cursor-pointer items-center gap-2 whitespace-nowrap rounded-lg border border-white/15 px-4 py-2 text-sm font-semibold text-white/80 transition hover:border-[#2E9BFF]/60 hover:text-white"
          >
            <i className="ri-lock-line" />
            Se connecter
          </Link>

          <Link
            href="/outils/qrcode"
            className="inline-flex cursor-pointer items-center gap-2 whitespace-nowrap rounded-lg bg-[#E60000] px-4 py-2 text-sm font-semibold text-white shadow-[0_8px_24px_-10px_rgba(230,0,0,0.9)] transition hover:bg-[#ff1a1a]"
          >
            <i className="ri-qr-code-line" />
            Créer un QR Code
          </Link>
        </div>
      </div>
    </header>
  );
}