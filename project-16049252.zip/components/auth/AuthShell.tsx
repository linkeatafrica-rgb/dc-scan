import Link from "next/link";
import BrandLogo from "../BrandLogo";

type AuthShellProps = {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  footer: React.ReactNode;
};

export default function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: AuthShellProps) {
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#F6F8FB]">
      <div className="pointer-events-none absolute -left-32 -top-32 h-[420px] w-[420px] rounded-full bg-[#2E9BFF]/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -right-28 h-[420px] w-[420px] rounded-full bg-[#E60000]/10 blur-3xl" />

      <div className="relative mx-auto flex min-h-screen w-full max-w-[1120px] flex-col px-5 py-6 sm:px-8">
        <header className="flex items-center justify-between">
          <Link href="/" className="flex cursor-pointer items-center gap-3">
            <BrandLogo height={30} />
            <span className="hidden rounded-md bg-white px-2 py-0.5 text-[11px] font-medium text-slate-500 ring-1 ring-slate-200 sm:inline">
              Outils
            </span>
          </Link>
          <Link
            href="/"
            className="inline-flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:border-[#001F3F]/30 hover:text-[#001F3F]"
          >
            <i className="ri-arrow-left-line" />
            Accueil
          </Link>
        </header>

        <main className="flex flex-1 items-center justify-center py-10">
          <div className="w-full max-w-[440px]">
            <div className="rounded-2xl border border-slate-200/80 bg-white p-7 shadow-[0_24px_60px_-40px_rgba(0,31,63,0.45)] sm:p-8">
              <h1 className="text-[26px] font-bold tracking-tight text-[#001F3F]">
                {title}
              </h1>
              <p className="mt-2 text-sm leading-relaxed text-slate-500">
                {subtitle}
              </p>
              <div className="mt-6">{children}</div>
            </div>

            <div className="mt-5 text-center text-sm text-slate-500">
              {footer}
            </div>
          </div>
        </main>

        <footer className="pb-2 text-center text-xs text-slate-400">
          © DC Scan — Générateur de QR Codes professionnels
        </footer>
      </div>
    </div>
  );
}