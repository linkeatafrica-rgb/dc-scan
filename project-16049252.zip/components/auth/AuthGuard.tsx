"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../../lib/useAuth";

export default function AuthGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/login");
    }
  }, [loading, user, router]);

  if (loading || !user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-gray-50">
        <span className="h-9 w-9 animate-spin rounded-full border-2 border-slate-200 border-t-[#001F3F] " />
        <p className="text-sm text-slate-400">Vérification de votre accès…</p>
      </div>
    );
  }

  return <>{children}</>;
}