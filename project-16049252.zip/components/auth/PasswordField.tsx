"use client";

import { useState } from "react";

type PasswordFieldProps = {
  value: string;
  onChange: (value: string) => void;
  label?: string;
};

export default function PasswordField({
  value,
  onChange,
  label = "Mot de passe",
}: PasswordFieldProps) {
  const [visible, setVisible] = useState(false);

  return (
    <label className="block min-w-0">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
        {label}
      </span>
      <span className="relative block">
        <i className="ri-lock-2-line pointer-events-none absolute left-3 top-1/2 flex h-4 w-4 -translate-y-1/2 items-center justify-center text-base text-slate-400" />
        <input
          type={visible ? "text" : "password"}
          name="password"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          autoComplete="current-password"
          placeholder="••••••••"
          required
          className="box-border w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-11 text-sm text-slate-900 outline-none transition placeholder:text-slate-300 focus:border-[#001F3F]/40 focus:ring-2 focus:ring-[#001F3F]/10"
        />
        <button
          type="button"
          onClick={() => setVisible((prev) => !prev)}
          aria-label={visible ? "Masquer le mot de passe" : "Afficher le mot de passe"}
          className="absolute right-2 top-1/2 flex h-7 w-7 -translate-y-1/2 cursor-pointer items-center justify-center rounded-md text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
        >
          <i className={visible ? "ri-eye-off-line" : "ri-eye-line"} />
        </button>
      </span>
    </label>
  );
}