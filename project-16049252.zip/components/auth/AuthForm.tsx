"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";
import { useAuth } from "../../lib/useAuth";
import PasswordField from "./PasswordField";

type AuthFormProps = {
  mode: "login" | "register";
};

const MESSAGES: Record<string, string> = {
  "Invalid login credentials": "Email ou mot de passe incorrect.",
  "Email not confirmed": "Votre email n'a pas encore été confirmé.",
  "User already registered": "Un compte existe déjà avec cet email.",
  "Password should be at least 6 characters":
    "Le mot de passe doit contenir au moins 6 caractères.",
  "Unable to validate email address: invalid format":
    "Cet email n'est pas valide.",
  "Email rate limit exceeded":
    "Trop de tentatives. Patientez quelques minutes avant de réessayer.",
};

export default function AuthForm({ mode }: AuthFormProps) {
  const router = useRouter();
  const { user, loading: checking } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!checking && user) {
      router.replace("/outils/qrcode");
    }
  }, [checking, user, router]);

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    setInfo("");

    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail || !cleanEmail.includes("@")) {
      setError("Saisissez une adresse email valide.");
      return;
    }
    if (password.length < 6) {
      setError("Le mot de passe doit contenir au moins 6 caractères.");
      return;
    }

    setLoading(true);
    try {
      if (mode === "login") {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });
        if (signInError) {
          setError(MESSAGES[signInError.message] || signInError.message);
          return;
        }
        router.replace("/outils/qrcode");
        return;
      }

      const { data, error: signUpError } = await supabase.auth.signUp({
        email: cleanEmail,
        password,
      });
      if (signUpError) {
        setError(MESSAGES[signUpError.message] || signUpError.message);
        return;
      }
      if (data.session) {
        router.replace("/outils/qrcode");
        return;
      }
      setInfo("Compte créé. Vérifiez votre boîte mail pour confirmer votre adresse.");
    } catch {
      setError("Une erreur est survenue. Réessayez dans un instant.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
      <label className="block min-w-0">
        <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
          Email
        </span>
        <span className="relative block">
          <i className="ri-mail-line pointer-events-none absolute left-3 top-1/2 flex h-4 w-4 -translate-y-1/2 items-center justify-center text-base text-slate-400" />
          <input
            type="email"
            name="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            autoComplete="email"
            placeholder="vous@entreprise.com"
            required
            className="box-border w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-300 focus:border-[#001F3F]/40 focus:ring-2 focus:ring-[#001F3F]/10"
          />
        </span>
      </label>

      <PasswordField value={password} onChange={setPassword} />

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5">
          <i className="ri-error-warning-line mt-0.5 flex h-4 w-4 items-center justify-center text-base text-[#E60000]" />
          <p className="text-xs leading-relaxed text-[#B00000]">{error}</p>
        </div>
      )}

      {info && (
        <div className="flex items-start gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2.5">
          <i className="ri-checkbox-circle-line mt-0.5 flex h-4 w-4 items-center justify-center text-base text-emerald-600" />
          <p className="text-xs leading-relaxed text-emerald-700">{info}</p>
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="mt-1 inline-flex w-full cursor-pointer items-center justify-center gap-2 whitespace-nowrap rounded-lg bg-[#E60000] px-5 py-3 text-sm font-semibold text-white shadow-[0_12px_28px_-14px_rgba(230,0,0,0.9)] transition hover:bg-[#ff1a1a] disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading ? (
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
        ) : (
          <i className={mode === "login" ? "ri-login-circle-line" : "ri-user-add-line"} />
        )}
        {mode === "login" ? "Se connecter" : "Créer un compte"}
      </button>
    </form>
  );
}