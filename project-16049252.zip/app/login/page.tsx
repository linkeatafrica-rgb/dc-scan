import type { Metadata } from "next";
import Link from "next/link";
import AuthShell from "../../components/auth/AuthShell";
import AuthForm from "../../components/auth/AuthForm";

export const metadata: Metadata = {
  title: "Connexion — DC Scan",
  description: "Connectez-vous à votre espace DC Scan pour créer vos QR codes.",
};

export default function LoginPage() {
  return (
    <AuthShell
      title="Connexion"
      subtitle="Accédez à votre générateur de QR Codes sécurisé."
      footer={
        <span>
          Pas encore de compte ?{" "}
          <Link
            href="/register"
            className="cursor-pointer font-semibold text-[#001F3F] underline decoration-[#E60000]/40 decoration-2 underline-offset-2 hover:text-[#E60000]"
          >
            Créer un compte
          </Link>
        </span>
      }
    >
      <AuthForm mode="login" />
    </AuthShell>
  );
}