'use client';

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { deleteDocument, listDocuments } from "../../lib/documentStorage";
import type { StoredDocument } from "../../lib/documentStorage";

function formatSize(size: number | null) {
  if (!size) return "—";
  if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} Ko`;
  return `${(size / (1024 * 1024)).toFixed(1)} Mo`;
}

function formatDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" });
}

export default function DocumentsList() {
  const [docs, setDocs] = useState<StoredDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [pending, setPending] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError("");
    try {
      setDocs(await listDocuments());
    } catch {
      setError("Impossible de charger vos documents. Réessayez dans un instant.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const remove = async (doc: StoredDocument) => {
    setPending(doc.id);
    setError("");
    try {
      await deleteDocument(doc);
      setDocs((prev) => prev.filter((item) => item.id !== doc.id));
      setConfirmId(null);
    } catch {
      setError("Suppression impossible. Réessayez dans un instant.");
    } finally {
      setPending(null);
    }
  };

  return (
    <div className="mx-auto w-full max-w-[880px] px-5 pb-16 pt-8 sm:px-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">
            Espace formateur
          </p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight text-[#001F3F] sm:text-3xl">
            Mes attestations
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Tous les fichiers envoyés ici restent accessibles de façon permanente.
          </p>
        </div>
        <Link
          href="/outils/qrcode"
          className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-[#001F3F] px-4 py-2.5 text-sm font-bold text-white transition hover:bg-[#00152b] whitespace-nowrap"
        >
          <i className="ri-qr-code-line text-base" />
          Créer un QR Code
        </Link>
      </div>

      {error && (
        <p className="mt-5 flex items-start gap-2 rounded-xl border border-[#E60000]/20 bg-[#E60000]/5 px-4 py-3 text-xs font-medium text-[#C40000]">
          <i className="ri-error-warning-line mt-0.5 shrink-0" />
          {error}
        </p>
      )}

      {loading ? (
        <div className="mt-8 flex items-center justify-center rounded-2xl border border-slate-200 bg-white py-16 text-sm font-medium text-slate-400">
          <i className="ri-loader-4-line mr-2 animate-spin text-xl text-[#001F3F]" />
          Chargement de vos documents…
        </div>
      ) : docs.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#001F3F]/5 text-[#001F3F]">
            <i className="ri-folder-open-line text-3xl" />
          </span>
          <p className="mt-4 text-base font-bold text-[#001F3F]">Aucun document pour le moment</p>
          <p className="mx-auto mt-1 max-w-sm text-sm leading-relaxed text-slate-500">
            Envoyez une attestation depuis le générateur : elle apparaîtra ici et pourra être
            supprimée à tout moment.
          </p>
        </div>
      ) : (
        <ul className="mt-6 space-y-3">
          {docs.map((doc) => (
            <li
              key={doc.id}
              className="rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_1px_2px_rgba(16,24,40,0.04),0_18px_40px_-34px_rgba(0,31,63,0.5)]"
            >
              <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#001F3F]/5 text-[#001F3F]">
                  <i className="ri-file-pdf-2-line text-xl" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-[#001F3F]">{doc.fileName}</p>
                  <p className="mt-0.5 text-xs text-slate-400">
                    {formatDate(doc.createdAt)} · {formatSize(doc.fileSize)}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <a
                    href={doc.publicUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition hover:border-[#001F3F]/40 hover:text-[#001F3F]"
                    aria-label="Ouvrir le document"
                  >
                    <i className="ri-external-link-line" />
                  </a>
                  <button
                    type="button"
                    onClick={() => setConfirmId(doc.id)}
                    className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-lg border border-[#E60000]/25 bg-[#E60000]/5 text-[#C40000] transition hover:border-[#E60000]/50"
                    aria-label="Supprimer le document"
                  >
                    <i className="ri-delete-bin-line" />
                  </button>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#F7F9FC] px-3 py-2">
                <p className="min-w-0 flex-1 truncate text-[11px] text-slate-400">
                  {doc.publicUrl}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    if (navigator.clipboard) void navigator.clipboard.writeText(doc.publicUrl);
                  }}
                  className="cursor-pointer text-[11px] font-semibold text-[#001F3F] underline whitespace-nowrap"
                >
                  Copier le lien
                </button>
              </div>

              {confirmId === doc.id && (
                <div className="mt-3 rounded-xl border border-[#E60000]/25 bg-[#E60000]/5 p-3">
                  <p className="text-xs font-medium leading-relaxed text-[#C40000]">
                    Supprimer définitivement ce fichier ? Les QR codes qui pointent vers ce
                    document ne fonctionneront plus.
                  </p>
                  <div className="mt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={() => void remove(doc)}
                      disabled={pending === doc.id}
                      className="cursor-pointer rounded-lg bg-[#E60000] px-3 py-2 text-xs font-bold text-white transition hover:bg-[#c90000] disabled:cursor-wait disabled:opacity-80 whitespace-nowrap"
                    >
                      {pending === doc.id ? "Suppression…" : "Oui, supprimer"}
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmId(null)}
                      className="cursor-pointer rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-600 transition hover:border-[#001F3F]/40 whitespace-nowrap"
                    >
                      Annuler
                    </button>
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}