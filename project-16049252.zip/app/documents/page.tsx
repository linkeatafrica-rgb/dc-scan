import type { Metadata } from "next";
import { Inter } from "next/font/google";
import AuthGuard from "../../components/auth/AuthGuard";
import ToolHeader from "../outils/qrcode/ToolHeader";
import DocumentsList from "./DocumentsList";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Mes attestations — DC Scan",
  description: "Consultez, copiez le lien ou supprimez vos attestations stockées.",
};

export default function DocumentsPage() {
  return (
    <div className={`${inter.className} min-h-screen bg-[#F7F9FC]`}>
      <AuthGuard>
        <ToolHeader />
        <DocumentsList />
      </AuthGuard>
    </div>
  );
}