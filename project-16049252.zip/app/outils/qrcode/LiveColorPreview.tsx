'use client';

import { QRCodeCanvas } from "qrcode.react";

type Props = {
  value: string;
  fgColor: string;
  bgColor: string;
};

export default function LiveColorPreview({ value, fgColor, bgColor }: Props) {
  const ready = value.trim().length > 0;

  return (
    <div className="flex min-w-0 flex-1 items-center gap-3 rounded-xl border border-slate-200 bg-white p-2">
      <div
        className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-slate-200 p-1"
        style={{ backgroundColor: bgColor }}
        suppressHydrationWarning
      >
        {ready ? (
          <QRCodeCanvas
            value={value}
            size={112}
            level="Q"
            bgColor={bgColor}
            fgColor={fgColor}
            marginSize={1}
            className="h-full w-full"
          />
        ) : (
          <span className="flex h-full w-full items-center justify-center text-slate-300">
            <i className="ri-qr-code-line text-xl" />
          </span>
        )}
      </div>

      <div className="min-w-0">
        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
          Aperçu en direct
        </p>
        <p className="mt-0.5 text-xs leading-snug text-slate-500">
          {ready
            ? "Vos couleurs s'appliquent immédiatement au QR code."
            : "Ajoutez l'information pour voir l'aperçu."}
        </p>
      </div>
    </div>
  );
}