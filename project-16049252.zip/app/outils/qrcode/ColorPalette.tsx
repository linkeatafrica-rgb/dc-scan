'use client';

type Props = {
  label: string;
  value: string;
  presets: string[];
  onChange: (color: string) => void;
  pickerLabel: string;
};

export default function ColorPalette({
  label,
  value,
  presets,
  onChange,
  pickerLabel,
}: Props) {
  return (
    <div className="min-w-0">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
          {label}
        </p>
        <span
          className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase text-slate-500"
          suppressHydrationWarning
        >
          <span
            className="h-2.5 w-2.5 rounded-full border border-slate-200"
            style={{ backgroundColor: value }}
          />
          {value}
        </span>
      </div>

      <div
        className="mt-2 flex w-full items-center gap-2 overflow-x-auto scroll-smooth pb-1 [scrollbar-width:thin] [&::-webkit-scrollbar]:h-1 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-slate-300"
      >
        {presets.map((color) => {
          const active = value.toLowerCase() === color.toLowerCase();
          return (
            <button
              key={color}
              type="button"
              onClick={() => onChange(color)}
              style={{ backgroundColor: color }}
              title={color}
              aria-label={`${label} ${color}`}
              aria-pressed={active}
              className={`h-8 w-8 shrink-0 cursor-pointer rounded-lg border transition ${
                active
                  ? "border-[#001F3F] ring-2 ring-[#001F3F]/25"
                  : "border-slate-200/90 hover:scale-105 hover:border-slate-300"
              }`}
            />
          );
        })}

        <span className="h-6 w-px shrink-0 bg-slate-200" />

        <label
          className="group relative h-8 w-8 shrink-0 cursor-pointer overflow-hidden rounded-lg border border-dashed border-slate-300 bg-white transition hover:border-[#001F3F]"
          title={pickerLabel}
        >
          <span
            className="pointer-events-none absolute inset-0 opacity-90"
            style={{
              background:
                "conic-gradient(from 210deg, #ef4444, #f59e0b, #22c55e, #06b6d4, #6366f1, #d946ef, #ef4444)",
            }}
          />
          <span className="pointer-events-none absolute inset-[3px] flex items-center justify-center rounded-[5px] bg-white/85 text-[13px] font-bold text-[#001F3F]">
            +
          </span>
          <input
            type="color"
            value={value}
            onChange={(event) => onChange(event.target.value)}
            aria-label={pickerLabel}
            title={pickerLabel}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          />
        </label>
      </div>
    </div>
  );
}