'use client';

type Props = {
  id: string;
  label: string;
  icon: string;
  placeholder: string;
  hint?: string;
  value: string;
  onChange: (value: string) => void;
};

export default function TextField({
  id,
  label,
  icon,
  placeholder,
  hint,
  value,
  onChange,
}: Props) {
  return (
    <div>
      <label htmlFor={id} className="text-sm font-bold text-[#001F3F]">
        {label}
      </label>
      <div className="mt-2 flex items-center gap-2 rounded-2xl border-2 border-slate-200 bg-white px-4 transition focus-within:border-[#001F3F]">
        <i className={`${icon} text-lg text-slate-400`} />
        <input
          id={id}
          type="text"
          value={value}
          maxLength={80}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          className="h-14 w-full min-w-0 bg-transparent text-base text-slate-800 outline-none placeholder:text-slate-400"
        />
        {value.length > 0 && (
          <button
            type="button"
            onClick={() => onChange("")}
            className="shrink-0 cursor-pointer text-xl text-slate-300 transition hover:text-[#E60000]"
            aria-label="Effacer"
          >
            <i className="ri-close-circle-fill" />
          </button>
        )}
      </div>
      {hint && <p className="mt-2 text-xs leading-relaxed text-slate-400">{hint}</p>}
    </div>
  );
}