'use client';

import Link from "next/link";
import TextField from "./TextField";
import MediaSourceField from "./MediaSourceField";
import type { useQrTarget } from "./lib/useQrTarget";

type Props = {
  target: ReturnType<typeof useQrTarget>;
};

export default function AttestationFields({ target }: Props) {
  return (
    <div>
      <TextField
        id="qr-att-title"
        label="Titre de l'attestation"
        icon="ri-award-line"
        placeholder="Ex : Attestation – Formation Bureautique 2026"
        hint="Ce titre s'affiche en haut de la page vue par le participant."
        value={target.attTitle}
        onChange={target.setAttTitle}
      />

      <div className="mt-4">
        <p className="mb-3 flex items-start gap-1.5 rounded-xl border border-[#001F3F]/15 bg-[#001F3F]/5 px-3 py-2 text-[11px] font-medium leading-relaxed text-[#001F3F]">
          <i className="ri-shield-check-line mt-0.5 shrink-0 text-sm" />
          <span>
            Envoyez le PDF ou l&apos;image : il est conservé de façon permanente sur votre espace
            sécurisé. Le QR code ouvre une page propre avec un bouton « Télécharger ».
          </span>
        </p>
        <MediaSourceField
          kind="file"
          mode={target.attMode}
          onModeChange={target.setAttMode}
          directLink={target.attDirect}
          onDirectLinkChange={target.setAttDirect}
          fileName={target.attName}
          fileLink={target.attHosted}
          onUploaded={target.setAtt}
          onCleared={target.clearAtt}
        />

        <Link
          href="/documents"
          className="mt-3 inline-flex cursor-pointer items-center gap-1.5 text-xs font-semibold text-[#001F3F] underline whitespace-nowrap"
        >
          <i className="ri-folder-shield-2-line" />
          Gérer mes attestations envoyées
        </Link>
      </div>
    </div>
  );
}