"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import BrandLogo from "../../../components/BrandLogo";
import { useAuth } from "../../../lib/useAuth";

export default function ToolHeader() {
  const router = useRouter();
  const { user, signOut } = useAuth();

  const logout = async () => {
    await signOut();
    router.replace("/login");
  };

  return (
    <header className="border-b border-slate-200/80 bg-white">
      <div className="mx-auto flex h-16 w-full max-w-[1240px] items-center justify-between px-5 sm:px-8">
        <Link href="/" className="flex items-center gap-3">
          <BrandLogo height={30} />
          <span className="hidden rounded-md bg-gray-50 px-2 py-0.5 text-[11px] font-medium text-slate-500 sm:inline">
            Outils
          </span>
        </Link>

        <div className="flex items-center gap-3">
          {user?.email && (
            <span className="hidden max-w-[220px] truncate text-xs text-slate-400 md:inline">
              {user.email}
            </span>
          )}
          <Link
            href="/documents"
            className="inline-flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:border-[#001F3F]/30 hover:text-[#001F3F]"
          >
            <i className="ri-folder-shield-2-line" />
            <span className="hidden sm:inline">Mes attestations</span>
          </Link>
          <Link
            href="/"
            className="inline-flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:border-[#001F3F]/30 hover:text-[#001F3F]"
          >
            <i className="ri-arrow-left-line" />
            Accueil
          </Link>
          <button
            type="button"
            onClick={logout}
            className="inline-flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-lg border border-[#E60000]/25 bg-[#E60000]/5 px-3 py-1.5 text-xs font-semibold text-[#C40000] transition hover:border-[#E60000]/50 hover:bg-[#E60000]/10"
          >
            <i className="ri-logout-box-r-line" />
            Déconnexion
          </button>
        </div>
      </div>
    </header>
  );
}