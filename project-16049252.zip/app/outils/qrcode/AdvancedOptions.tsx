'use client';

import { useState } from "react";
import ColorPalette from "./ColorPalette";
import LiveColorPreview from "./LiveColorPreview";

type Props = {
  value: string;
  fgColor: string;
  bgColor: string;
  onFgChange: (color: string) => void;
  onBgChange: (color: string) => void;
};

const DEFAULT_FG = "#001F3F";
const DEFAULT_BG = "#FFFFFF";

const FG_PRESETS = [
  "#001F3F", "#000000", "#111827", "#1F2937", "#334155", "#475569",
  "#64748B", "#0F766E", "#059669", "#16A34A", "#65A30D", "#CA8A04",
  "#D97706", "#EA580C", "#E60000", "#DC2626", "#BE123C", "#DB2777",
  "#C026D3", "#9333EA", "#7C3AED", "#4C1D95", "#312E81", "#0E7490",
  "#0891B2", "#0284C7", "#1D4ED8", "#8B5E3C",
];

const BG_PRESETS = [
  "#FFFFFF", "#FEFEFE", "#F8FAFC", "#F1F5F9", "#E2E8F0", "#E7E5E4",
  "#FEF2F2", "#FEE2E2", "#FFF1F2", "#FFFBEB", "#FEF3C7", "#FEFCE8",
  "#F7FEE7", "#ECFDF5", "#D1FAE5", "#ECFEFF", "#E0F2FE", "#DBEAFE",
  "#EEF2FF", "#EDE9FE", "#F5F3FF", "#FAE8FF", "#FCE7F3", "#FFF7ED",
  "#F5EDE6", "#EAF3F1", "#EEF5EA", "#F4F4F5",
];

export default function AdvancedOptions({
  value,
  fgColor,
  bgColor,
  onFgChange,
  onBgChange,
}: Props) {
  const [open, setOpen] = useState(false);
  const isDefault =
    fgColor.toLowerCase() === DEFAULT_FG.toLowerCase() &&
    bgColor.toLowerCase() === DEFAULT_BG.toLowerCase();

  const reset = () => {
    onFgChange(DEFAULT_FG);
    onBgChange(DEFAULT_BG);
  };

  return (
    <div className="border-t border-slate-100 pt-3">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex w-full cursor-pointer items-center justify-center gap-1.5 text-xs font-medium text-slate-400 transition hover:text-[#001F3F] whitespace-nowrap"
        aria-expanded={open}
      >
        <i className="ri-settings-3-line" />
        Options avancées
        <i className={open ? "ri-arrow-up-s-line" : "ri-arrow-down-s-line"} />
      </button>

      {open && (
        <div className="mt-3 space-y-4 overflow-hidden rounded-xl bg-gray-50 p-3 sm:p-4">
          <div className="flex flex-wrap items-center gap-2">
            <LiveColorPreview value={value} fgColor={fgColor} bgColor={bgColor} />

            <button
              type="button"
              onClick={reset}
              disabled={isDefault}
              className="flex shrink-0 cursor-pointer items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-[#001F3F] transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40 whitespace-nowrap"
            >
              <i className="ri-restart-line" />
              Réinitialiser les couleurs
            </button>
          </div>

          <ColorPalette
            label="Couleur des points"
            value={fgColor}
            presets={FG_PRESETS}
            onChange={onFgChange}
            pickerLabel="Choisir une couleur de points personnalisée"
          />

          <ColorPalette
            label="Couleur du fond"
            value={bgColor}
            presets={BG_PRESETS}
            onChange={onBgChange}
            pickerLabel="Choisir une couleur de fond personnalisée"
          />

          <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-slate-400">
            <i className="ri-information-line mt-px shrink-0" />
            Faites glisser la palette pour voir toutes les nuances. Le bouton
            arc-en-ciel ouvre le sélecteur de couleur libre.
          </p>
        </div>
      )}
    </div>
  );
}