export async function downloadHostedFile(link: string, fileName: string) {
  const response = await fetch(link);
  if (!response.ok) throw new Error("download");
  const blob = await response.blob();
  if (!blob.size) throw new Error("download");

  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = fileName || "mon-fichier";
  anchor.rel = "noopener";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
}