'use client';

import { useEffect, useMemo, useState } from "react";
import { buildTel, buildWhatsApp, ensureUrl } from "./qrTypes";
import type { QrTypeId } from "./qrTypes";

export type MediaMode = "upload" | "link";

export function useQrTarget() {
  const [type, setType] = useState<QrTypeId>("web");
  const [webUrl, setWebUrl] = useState("");
  const [paymentUrl, setPaymentUrl] = useState("");
  const [docUrl, setDocUrl] = useState("");
  const [phone, setPhone] = useState("");

  const [photoMode, setPhotoMode] = useState<MediaMode>("upload");
  const [photoName, setPhotoName] = useState("");
  const [photoHosted, setPhotoHosted] = useState("");
  const [photoDirect, setPhotoDirect] = useState("");

  const [fileMode, setFileMode] = useState<MediaMode>("upload");
  const [fileName, setFileName] = useState("");
  const [fileHosted, setFileHosted] = useState("");
  const [fileDirect, setFileDirect] = useState("");

  const [attTitle, setAttTitle] = useState("");
  const [attMode, setAttMode] = useState<MediaMode>("upload");
  const [attDirect, setAttDirect] = useState("");
  const [attName, setAttName] = useState("");
  const [attHosted, setAttHosted] = useState("");
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    setOrigin(window.location.origin);
  }, []);

  const value = useMemo(() => {
    if (type === "web") return ensureUrl(webUrl);
    if (type === "payment") return ensureUrl(paymentUrl);
    if (type === "online") return ensureUrl(docUrl);
    if (type === "whatsapp") return buildWhatsApp(phone);
    if (type === "phone") return buildTel(phone);
    if (type === "photo") return photoMode === "upload" ? photoHosted : ensureUrl(photoDirect);
    if (type === "file") return fileMode === "upload" ? fileHosted : ensureUrl(fileDirect);
    if (type === "attestation") {
      const doc = attMode === "upload" ? attHosted : ensureUrl(attDirect);
      if (!doc || !origin) return "";
      const title = attTitle.trim();
      return `${origin}/attestation?src=${encodeURIComponent(doc)}${title ? `&n=${encodeURIComponent(title)}` : ""}`;
    }
    return "";
  }, [
    type,
    webUrl,
    paymentUrl,
    docUrl,
    phone,
    photoMode,
    photoHosted,
    photoDirect,
    fileMode,
    fileHosted,
    fileDirect,
    attMode,
    attHosted,
    attDirect,
    attTitle,
    origin,
  ]);

  const temporary = false;

  const reset = () => {
    setWebUrl("");
    setPaymentUrl("");
    setDocUrl("");
    setPhone("");
    setPhotoMode("upload");
    setPhotoName("");
    setPhotoHosted("");
    setPhotoDirect("");
    setFileMode("upload");
    setFileName("");
    setFileHosted("");
    setFileDirect("");
    setAttTitle("");
    setAttMode("upload");
    setAttDirect("");
    setAttName("");
    setAttHosted("");
  };

  return {
    type,
    setType,
    webUrl,
    setWebUrl,
    paymentUrl,
    setPaymentUrl,
    docUrl,
    setDocUrl,
    phone,
    setPhone,
    photoMode,
    setPhotoMode,
    photoName,
    photoHosted,
    photoDirect,
    setPhotoDirect,
    setPhoto: (name: string, link: string) => {
      setPhotoName(name);
      setPhotoHosted(link);
    },
    clearPhoto: () => {
      setPhotoName("");
      setPhotoHosted("");
    },
    fileMode,
    setFileMode,
    fileName,
    fileHosted,
    fileDirect,
    setFileDirect,
    setFile: (name: string, link: string) => {
      setFileName(name);
      setFileHosted(link);
    },
    clearFile: () => {
      setFileName("");
      setFileHosted("");
    },
    attTitle,
    setAttTitle,
    attMode,
    setAttMode,
    attDirect,
    setAttDirect,
    attName,
    attHosted,
    setAtt: (name: string, link: string) => {
      setAttName(name);
      setAttHosted(link);
    },
    clearAtt: () => {
      setAttName("");
      setAttHosted("");
    },
    temporary,
    reset,
    value,
  };
}