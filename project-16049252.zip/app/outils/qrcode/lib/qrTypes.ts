export type QrTypeId =
  | "web"
  | "whatsapp"
  | "phone"
  | "photo"
  | "file"
  | "attestation"
  | "payment"
  | "online";

export type QrTypeMeta = {
  id: QrTypeId;
  label: string;
  short: string;
  ask: string;
  emoji: string;
  description: string;
  icon: string;
};

export const QR_TYPES: QrTypeMeta[] = [
  {
    id: "web",
    label: "Mon site internet",
    short: "Un lien vers une page",
    ask: "Collez le lien de votre site",
    emoji: "🔗",
    description: "Un QR code qui ouvre votre site internet, un article ou une page.",
    icon: "ri-global-line",
  },
  {
    id: "whatsapp",
    label: "WhatsApp",
    short: "Discuter sur WhatsApp",
    ask: "Entrez votre numéro WhatsApp",
    emoji: "📱",
    description: "Le client scanne et arrive directement dans votre WhatsApp.",
    icon: "ri-whatsapp-line",
  },
  {
    id: "phone",
    label: "Appeler",
    short: "Appel direct",
    ask: "Entrez votre numéro de téléphone",
    emoji: "📞",
    description: "Le scan lance un appel vers votre numéro.",
    icon: "ri-phone-line",
  },
  {
    id: "photo",
    label: "Photo",
    short: "Montrer une image",
    ask: "Ajoutez votre photo",
    emoji: "🖼️",
    description: "Partagez une photo, un visuel ou un catalogue.",
    icon: "ri-image-line",
  },
  {
    id: "file",
    label: "Fichier / PDF",
    short: "Partager un document",
    ask: "Ajoutez votre fichier ou son lien",
    emoji: "📄",
    description: "Un QR code qui ouvre votre PDF, votre catalogue ou votre fiche.",
    icon: "ri-file-pdf-line",
  },
  {
    id: "attestation",
    label: "Attestation",
    short: "Diplôme ou certificat",
    ask: "Ajoutez votre attestation de formation",
    emoji: "🎓",
    description:
      "Une page propre qui affiche l'attestation et permet de la télécharger sur le téléphone.",
    icon: "ri-award-line",
  },
  {
    id: "payment",
    label: "Paiement",
    short: "Encaisser de l'argent",
    ask: "Collez votre lien de paiement",
    emoji: "💳",
    description: "Vos clients paient avec Flooz, T-Money, Moov Money…",
    icon: "ri-secure-payment-line",
  },
  {
    id: "online",
    label: "Document en ligne",
    short: "Google Docs, Drive",
    ask: "Collez le lien de votre document Google Docs",
    emoji: "📝",
    description: "Un QR code qui ouvre votre document en ligne (Google Docs, Sheets, Drive).",
    icon: "ri-file-text-line",
  },
];

export const PHONE_PREFIXES = ["+228", "+229", "+225", "+226", "+233"];

export function normalizePhone(input: string): string {
  const digits = input.replace(/\D/g, "");
  return digits.startsWith("00") ? digits.slice(2) : digits;
}

export function buildWhatsApp(phone: string): string {
  const number = normalizePhone(phone);
  return number ? `https://wa.me/${number}` : "";
}

export function buildTel(phone: string): string {
  const number = normalizePhone(phone);
  return number ? `tel:+${number}` : "";
}

export function ensureUrl(input: string): string {
  const value = input.trim();
  if (!value) return "";
  if (/^[a-z][a-z0-9+.-]*:/i.test(value)) return value;
  return `https://${value}`;
}

export function typeMeta(id: QrTypeId): QrTypeMeta {
  return QR_TYPES.find((item) => item.id === id) ?? QR_TYPES[0];
}