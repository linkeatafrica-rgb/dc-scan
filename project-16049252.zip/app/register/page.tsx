import type { Metadata } from "next";
import Link from "next/link";
import AuthShell from "../../components/auth/AuthShell";
import AuthForm from "../../components/auth/AuthForm";

export const metadata: Metadata = {
  title: "Créer un compte — DC Scan",
  description: "Créez votre compte DC Scan et générez vos QR codes professionnels.",
};

export default function RegisterPage() {
  return (
    <AuthShell
      title="Créer un compte"
      subtitle="Un email, un mot de passe, et c'est parti pour vos QR codes."
      footer={
        <span>
          Vous avez déjà un compte ?{" "}
          <Link
            href="/login"
            className="cursor-pointer font-semibold text-[#001F3F] underline decoration-[#E60000]/40 decoration-2 underline-offset-2 hover:text-[#E60000]"
          >
            Se connecter
          </Link>
        </span>
      }
    >
      <AuthForm mode="register" />
    </AuthShell>
  );
}