import { Suspense } from "react";
import DocumentViewer from "./DocumentViewer";

export const metadata = {
  title: "Attestation de formation — DC Scan",
  description: "Consultez et téléchargez votre attestation de formation.",
};

function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F7F9FC]">
      <span className="flex flex-col items-center gap-3 text-sm font-medium text-slate-400">
        <i className="ri-loader-4-line animate-spin text-2xl text-[#001F3F]" />
        Chargement du document…
      </span>
    </div>
  );
}

export default function AttestationPage() {
  return (
    <Suspense fallback={<Loading />}>
      <DocumentViewer />
    </Suspense>
  );
}