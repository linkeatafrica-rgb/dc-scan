'use client';

import { useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import BrandLogo from "../../components/BrandLogo";

function cleanUrl(url: string) {
  return url.split("#")[0];
}

function isImage(url: string) {
  return /\.(png|jpe?g|webp|gif|avif|bmp)(\?|$)/i.test(cleanUrl(url));
}

function buildFileName(url: string, title: string) {
  const path = cleanUrl(url).split("?")[0];
  const ext = path.match(/\.(pdf|png|jpe?g|webp|gif|avif)$/i)?.[0] ?? "";
  const base = (title || decodeURIComponent(path.split("/").pop() || "") || "attestation")
    .replace(/\.[a-z0-9]{2,5}$/i, "")
    .replace(/[\\/:*?"<>|]+/g, "-")
    .trim()
    .slice(0, 60);
  return `${base || "attestation"}${ext.toLowerCase()}`;
}

export default function DocumentViewer() {
  const params = useSearchParams();
  const src = (params.get("src") ?? "").trim();
  const title = (params.get("n") ?? "").trim();
  const valid = /^https?:\/\//i.test(src);
  const image = valid && isImage(src);
  const fileName = valid ? buildFileName(src, title) : "attestation";

  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const save = async () => {
    if (!valid || busy) return;
    setBusy(true);
    setMessage("");
    try {
      const response = await fetch(src);
      if (!response.ok) throw new Error("download");
      const blob = await response.blob();
      if (!blob.size) throw new Error("download");
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = objectUrl;
      anchor.download = fileName;
      anchor.rel = "noopener";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
      setMessage("Téléchargement lancé. Retrouvez le fichier dans vos téléchargements.");
    } catch {
      window.open(src, "_blank", "noopener");
      setMessage(
        "Le document s'ouvre dans un nouvel onglet. Touchez « Partager » puis « Enregistrer le fichier »."
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-[#F7F9FC] text-slate-900">
      <header className="border-b border-slate-200/80 bg-white">
        <div className="mx-auto flex h-16 w-full max-w-[1024px] items-center justify-between px-4 sm:px-8">
          <Link href="/" className="flex items-center gap-3">
            <BrandLogo height={28} />
          </Link>
          <span className="rounded-full bg-[#001F3F]/5 px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-[#001F3F]">
            Document sécurisé
          </span>
        </div>
      </header>

      <main className="mx-auto w-full max-w-[720px] flex-1 px-4 pb-14 pt-8 sm:px-6 sm:pt-12">
        {!valid ? (
          <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-[0_20px_50px_-40px_rgba(0,31,63,0.6)]">
            <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#E60000]/10 text-[#E60000]">
              <i className="ri-file-warning-line text-3xl" />
            </span>
            <h1 className="mt-5 text-xl font-bold text-[#001F3F] sm:text-2xl">
              Attestation introuvable
            </h1>
            <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-slate-500">
              Le lien utilisé est incomplet ou expiré. Demandez un nouveau QR code à votre
              organisme de formation.
            </p>
            <Link
              href="/"
              className="mt-6 inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-[#001F3F] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#00152b] whitespace-nowrap"
            >
              <i className="ri-home-4-line text-base" />
              Retour à l&apos;accueil
            </Link>
          </div>
        ) : (
          <>
            <div className="text-center">
              <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">
                Attestation de formation
              </p>
              <h1 className="mt-2 text-2xl font-bold leading-snug tracking-tight text-[#001F3F] sm:text-3xl">
                {title || "Votre attestation est prête"}
              </h1>
              <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-500">
                Vérifiez le document ci-dessous, puis enregistrez-le sur votre téléphone.
              </p>
            </div>

            <div className="mt-7 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-[0_24px_60px_-46px_rgba(0,31,63,0.7)]">
              {image ? (
                <div className="bg-slate-50 p-3 sm:p-4">
                  <img
                    src={src}
                    alt={title || "Attestation de formation"}
                    className="mx-auto max-h-[520px] w-auto max-w-full rounded-xl object-contain"
                  />
                </div>
              ) : (
                <>
                  <div className="hidden bg-slate-50 p-4 sm:block">
                    <iframe
                      src={src}
                      title={title || "Attestation de formation"}
                      className="h-[480px] w-full rounded-xl border border-slate-200 bg-white"
                    />
                  </div>
                  <div className="sm:hidden">
                    <div className="flex items-center gap-4 border-b border-slate-100 px-5 py-6">
                      <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-[#E60000]/10 text-[#E60000]">
                        <i className="ri-file-pdf-2-line text-3xl" />
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-bold text-[#001F3F]">{fileName}</p>
                        <p className="mt-1 text-xs text-slate-400">Document PDF prêt à enregistrer</p>
                      </div>
                    </div>
                  </div>
                </>
              )}

              <div className="border-t border-slate-100 px-4 py-4 sm:px-5">
                <p className="flex items-center gap-1.5 text-xs text-slate-400">
                  <i className="ri-shield-check-line text-sm text-emerald-600" />
                  Document officiel — à conserver sans modification.
                </p>

                {!image && (
                  <p className="mt-2 text-[11px] leading-relaxed text-slate-400">
                    Si l&apos;aperçu reste vide, utilisez l&apos;un des boutons ci-dessous :
                    le document s&apos;ouvrira directement sur votre téléphone.
                  </p>
                )}

                <button
                  type="button"
                  onClick={save}
                  disabled={busy}
                  className="mt-3 flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-[#E60000] px-5 py-4 text-base font-bold text-white shadow-[0_16px_30px_-18px_rgba(230,0,0,0.9)] transition hover:bg-[#c90000] active:scale-[0.99] disabled:cursor-wait disabled:opacity-80 whitespace-nowrap"
                >
                  <i
                    className={`${busy ? "ri-loader-4-line animate-spin" : "ri-download-2-line"} text-lg`}
                  />
                  {busy ? "Préparation…" : "Télécharger l'attestation"}
                </button>

                <a
                  href={src}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-slate-200 bg-white px-5 py-3.5 text-sm font-bold text-[#001F3F] transition hover:border-[#001F3F]/40 whitespace-nowrap"
                >
                  <i className="ri-external-link-line text-base" />
                  Ouvrir en plein écran
                </a>

                {message && (
                  <p className="mt-3 flex items-start gap-1.5 rounded-xl bg-[#001F3F]/5 px-3 py-2.5 text-xs font-medium leading-relaxed text-[#001F3F]">
                    <i className="ri-information-line mt-0.5 shrink-0" />
                    {message}
                  </p>
                )}
              </div>
            </div>

            <p className="mt-6 text-center text-xs text-slate-400">
              Un problème avec ce document ? Contactez votre organisme de formation.
            </p>
          </>
        )}
      </main>
    </div>
  );
}