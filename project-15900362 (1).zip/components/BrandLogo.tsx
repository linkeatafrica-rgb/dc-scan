export const LOGO_URL =
  "https://public.readdy.ai/ai/img_res/77f98d81-2ce0-4803-a296-98b2e599db91.png";

type BrandLogoProps = {
  height?: number;
  chip?: boolean;
  className?: string;
  glow?: boolean;
};

export default function BrandLogo({
  height = 36,
  chip = false,
  className = "",
  glow = false,
}: BrandLogoProps) {
  const image = (
    <img
      src={LOGO_URL}
      alt="DC Scan"
      style={{ height, width: "auto" }}
      loading="eager"
      decoding="async"
      className="block max-w-full select-none"
      draggable={false}
    />
  );

  if (!chip) {
    return <span className={`inline-flex items-center ${className}`}>{image}</span>;
  }

  return (
    <span
      className={`inline-flex items-center justify-center rounded-xl bg-white px-3.5 py-2 ring-1 ring-black/5 ${
        glow
          ? "shadow-[0_20px_60px_-20px_rgba(46,155,255,0.55)]"
          : "shadow-[0_8px_24px_-14px_rgba(0,0,0,0.9)]"
      } ${className}`}
    >
      {image}
    </span>
  );
}