const steps = [
  {
    number: "01",
    title: "Choisissez le type",
    text: "Site web, WhatsApp, appel, photo, PDF, paiement ou document en ligne.",
  },
  {
    number: "02",
    title: "Renseignez votre contenu",
    text: "Collez un lien ou un numéro, ou importez votre fichier en un clic.",
  },
  {
    number: "03",
    title: "Téléchargez",
    text: "Votre QR code est généré instantanément, en haute résolution.",
  },
];

export default function StepsSection() {
  return (
    <section id="fonctionnement" className="relative bg-[#020A14]">
      <div className="mx-auto w-full max-w-[1240px] px-5 py-16 sm:px-8 sm:py-20">
        <div className="max-w-2xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#ff4d4d]">
            Fonctionnement
          </p>
          <h2 className="mt-3 text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Trois étapes, aucune compétence technique
          </h2>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-5 md:grid-cols-3">
          {steps.map((step) => (
            <div
              key={step.number}
              className="rounded-2xl border border-white/10 bg-white/[0.03] p-7 transition hover:border-white/25"
            >
              <span className="text-sm font-bold tracking-[0.12em] text-[#2E9BFF]">
                {step.number}
              </span>
              <h3 className="mt-3 text-base font-semibold text-white">
                {step.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-white/60">
                {step.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}