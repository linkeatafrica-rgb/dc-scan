import Link from "next/link";

export default function CtaBand() {
  return (
    <section className="bg-[#020A14]">
      <div className="mx-auto w-full max-w-[1240px] px-5 pb-16 sm:px-8">
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#001F3F] via-[#04182C] to-[#1A0508] px-7 py-10 sm:px-12">
          <span className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-[#E60000]/25 blur-3xl" />
          <span className="pointer-events-none absolute -bottom-20 left-10 h-48 w-48 rounded-full bg-[#2E9BFF]/20 blur-3xl" />
          <div className="relative flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
                Prêt à créer votre premier QR code ?
              </h2>
              <p className="mt-2 text-sm text-white/60">
                Gratuit, sans compte et utilisable immédiatement.
              </p>
            </div>
            <Link
              href="/outils/qrcode"
              className="inline-flex cursor-pointer items-center gap-2 whitespace-nowrap rounded-xl bg-[#E60000] px-7 py-3.5 text-sm font-semibold text-white shadow-[0_14px_35px_-12px_rgba(230,0,0,0.9)] transition hover:bg-[#ff1a1a]"
            >
              Générer mon QR Code
              <i className="ri-arrow-right-line" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}