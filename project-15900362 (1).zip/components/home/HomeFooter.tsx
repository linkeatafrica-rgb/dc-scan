import Link from "next/link";
import BrandLogo from "../BrandLogo";

export default function HomeFooter() {
  return (
    <footer className="border-t border-white/10 bg-[#020A14]">
      <div className="mx-auto flex w-full max-w-[1240px] flex-col items-center justify-between gap-3 px-5 py-8 text-[11px] text-white/45 sm:flex-row sm:px-8 sm:text-xs">
        <div className="flex items-center gap-3">
          <BrandLogo height={22} chip />
          <span className="hidden text-white/30 sm:inline">
            Générateur de QR codes
          </span>
        </div>
        <div className="flex items-center gap-5">
          <Link
            href="/outils/qrcode"
            className="cursor-pointer transition hover:text-white"
          >
            Créer un QR code
          </Link>
          <span>© 2026 DC Scan</span>
        </div>
      </div>
    </footer>
  );
}