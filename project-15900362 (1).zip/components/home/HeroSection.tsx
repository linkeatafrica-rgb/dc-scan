import Link from "next/link";
import BrandLogo from "../BrandLogo";

const heroImage =
  "https://public.readdy.ai/ai/img_res/edited_3161b9c326879755f5b5b85546b5a216_d2b2c9e5.jpg";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-[#020A14]">
      <style>{`
        @keyframes dc-float {
          0%, 100% { transform: translate3d(0, 0, 0); }
          50% { transform: translate3d(0, -16px, 0); }
        }
        .dc-float { animation: dc-float 7s ease-in-out infinite; will-change: transform; }
        @keyframes dc-glow {
          0%, 100% { opacity: 0.5; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.05); }
        }
        .dc-glow { animation: dc-glow 7s ease-in-out infinite; }
        @media (prefers-reduced-motion: reduce) {
          .dc-float, .dc-glow { animation: none; }
        }
      `}</style>

      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_10%,rgba(46,155,255,0.18),transparent_58%)]" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#020A14] via-[#020A14]/70 to-transparent" />

      <div className="relative mx-auto w-full max-w-[1240px] px-5 pb-14 pt-12 text-center sm:px-8 lg:pt-16">
        <div className="mb-7 flex justify-center">
          <BrandLogo height={58} chip glow />
        </div>

        <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-[11px] font-medium text-white/80 backdrop-blur sm:text-xs">
          <i className="ri-sparkling-2-fill text-[#E60000]" />
          Générateur de QR codes pour les entreprises
        </span>

        <h1 className="mx-auto mt-7 max-w-4xl text-[30px] font-bold leading-[1.14] tracking-tight text-white sm:text-5xl lg:text-[58px]">
          Créez vos QR Codes professionnels en{" "}
          <span className="bg-gradient-to-r from-[#2E9BFF] to-[#E60000] bg-clip-text text-transparent">
            2 minutes.
          </span>
        </h1>

        <p className="mx-auto mt-5 max-w-xl text-[15px] leading-relaxed text-white/65 sm:text-lg">
          Des QR codes haute définition, sécurisés et prêts à imprimer pour votre
          entreprise.
        </p>

        <Link
          href="/outils/qrcode"
          className="mt-8 inline-flex cursor-pointer items-center justify-center gap-2.5 whitespace-nowrap rounded-xl bg-[#E60000] px-8 py-4 text-base font-semibold text-white shadow-[0_18px_45px_-12px_rgba(230,0,0,0.85)] transition hover:bg-[#ff1a1a] sm:px-12 sm:py-5 sm:text-lg"
        >
          <i className="ri-qr-code-line text-xl" />
          Générer mon QR Code
        </Link>

        <div className="mx-auto mt-10 flex w-full max-w-4xl items-center justify-center sm:mt-12">
          <div className="relative w-full">
            <span className="dc-glow pointer-events-none absolute left-1/2 top-1/2 h-[78%] w-[78%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#2E9BFF]/20 blur-3xl" />
            <span className="dc-glow pointer-events-none absolute left-[62%] top-[66%] h-[40%] w-[40%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#E60000]/20 blur-3xl" />
            <div className="dc-float relative">
              <img
                src={heroImage}
                alt="Enseigne néon 3D DC Scan QR Generator, bleu et rouge"
                width={1024}
                height={1024}
                loading="eager"
                decoding="async"
                className="mx-auto h-auto w-full max-w-[440px] object-contain sm:max-w-[600px] lg:max-w-[660px]"
              />
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px] text-white/50 sm:text-xs">
          <span className="inline-flex items-center gap-1.5">
            <i className="ri-check-line text-[#2E9BFF]" /> Sans inscription
          </span>
          <span className="inline-flex items-center gap-1.5">
            <i className="ri-check-line text-[#2E9BFF]" /> Aucune limite
          </span>
          <span className="inline-flex items-center gap-1.5">
            <i className="ri-check-line text-[#2E9BFF]" /> Téléchargement immédiat
          </span>
        </div>
      </div>
    </section>
  );
}