const benefits = [
  {
    icon: "ri-hd-line",
    title: "Haute définition",
    text: "Des images nettes jusqu'à 1856 px, prêtes pour l'impression sur flyer, affiche ou vitrine.",
    accent: "blue",
  },
  {
    icon: "ri-user-forbid-line",
    title: "Sans compte",
    text: "Aucune inscription, aucun email. Vous ouvrez l'outil, vous créez, vous téléchargez.",
    accent: "red",
  },
  {
    icon: "ri-money-euro-circle-line",
    title: "100 % gratuit",
    text: "Tous les types de QR codes sont accessibles gratuitement, sans filigrane ni limite cachée.",
    accent: "blue",
  },
];

export default function BenefitsSection() {
  return (
    <section id="avantages" className="relative bg-[#001F3F]">
      <div className="mx-auto w-full max-w-[1240px] px-5 py-16 sm:px-8 sm:py-20">
        <div className="max-w-2xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#2E9BFF]">
            Pourquoi DC Scan
          </p>
          <h2 className="mt-3 text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Simple, rapide et pensé pour le terrain
          </h2>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-5 md:grid-cols-3">
          {benefits.map((benefit) => (
            <div
              key={benefit.title}
              className="rounded-2xl border border-white/10 bg-[#03141F]/80 p-7 transition hover:border-white/25"
            >
              <span
                className={`flex h-11 w-11 items-center justify-center rounded-xl border ${
                  benefit.accent === "blue"
                    ? "border-[#2E9BFF]/35 bg-[#2E9BFF]/10 text-[#2E9BFF]"
                    : "border-[#E60000]/35 bg-[#E60000]/10 text-[#ff4d4d]"
                }`}
              >
                <i className={`${benefit.icon} text-xl`} />
              </span>
              <h3 className="mt-5 text-base font-semibold text-white">
                {benefit.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-white/60">
                {benefit.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}