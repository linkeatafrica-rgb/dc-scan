import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
})

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DC Scan — Générateur de QR Codes professionnels",
  description:
    "Créez des QR codes haute définition, sécurisés et prêts à imprimer pour votre entreprise en 2 minutes.",
  icons: {
    icon: [
      {
        url: "https://public.readdy.ai/ai/img_res/edited_0665967d5c6c9484dd1789a77a65f7a9_c7b3a2ae.jpg",
        type: "image/jpeg",
        sizes: "any",
      },
    ],
    shortcut:
      "https://public.readdy.ai/ai/img_res/edited_0665967d5c6c9484dd1789a77a65f7a9_c7b3a2ae.jpg",
    apple:
      "https://public.readdy.ai/ai/img_res/edited_0665967d5c6c9484dd1789a77a65f7a9_c7b3a2ae.jpg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning={true}>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
