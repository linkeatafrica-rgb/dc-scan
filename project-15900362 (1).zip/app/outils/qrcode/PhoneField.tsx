'use client';

import { PHONE_PREFIXES, buildTel, buildWhatsApp, normalizePhone } from "./lib/qrTypes";

type Props = {
  mode: "whatsapp" | "phone";
  value: string;
  onChange: (value: string) => void;
};

export default function PhoneField({ mode, value, onChange }: Props) {
  const digits = normalizePhone(value);
  const isTooShort = digits.length > 0 && digits.length < 8;
  const generated = mode === "whatsapp" ? buildWhatsApp(value) : buildTel(value);

  return (
    <div>
      <label htmlFor="qr-phone" className="text-sm font-bold text-[#001F3F]">
        Numéro de téléphone
      </label>
      <div className="mt-2 flex items-center gap-2 rounded-2xl border-2 border-slate-200 bg-white px-4 transition focus-within:border-[#001F3F]">
        <i
          className={`${
            mode === "whatsapp" ? "ri-whatsapp-line" : "ri-phone-line"
          } text-lg text-slate-400`}
        />
        <input
          id="qr-phone"
          type="tel"
          inputMode="tel"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder="+228 90 12 34 56"
          className="h-14 w-full min-w-0 bg-transparent text-base text-slate-800 outline-none placeholder:text-slate-400"
        />
        {value.length > 0 && (
          <button
            type="button"
            onClick={() => onChange("")}
            className="shrink-0 cursor-pointer text-xl text-slate-300 transition hover:text-[#E60000]"
            aria-label="Effacer"
          >
            <i className="ri-close-circle-fill" />
          </button>
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <span className="text-xs text-slate-400">Mon pays :</span>
        {PHONE_PREFIXES.map((prefix) => (
          <button
            key={prefix}
            type="button"
            onClick={() => onChange(`${prefix}${normalizePhone(value)}`)}
            className="cursor-pointer rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-bold text-slate-600 transition hover:border-[#001F3F] hover:text-[#001F3F] whitespace-nowrap"
          >
            {prefix}
          </button>
        ))}
      </div>

      {isTooShort ? (
        <p className="mt-3 flex items-start gap-1.5 rounded-xl bg-red-50 px-3 py-2 text-xs font-medium text-[#E60000]">
          <i className="ri-error-warning-line mt-0.5" />
          Numéro trop court. Ajoutez l&apos;indicatif, exemple +228.
        </p>
      ) : (
        <p className="mt-3 break-all rounded-xl bg-gray-50 px-3 py-2 text-xs text-slate-500">
          {generated || "Le lien sera créé automatiquement pour vous."}
        </p>
      )}
    </div>
  );
}