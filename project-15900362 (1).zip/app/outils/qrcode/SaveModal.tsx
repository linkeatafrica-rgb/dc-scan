'use client';

import { useEffect } from "react";

type Props = {
  imageUrl: string;
  onClose: () => void;
};

export default function SaveModal({ imageUrl, onClose }: Props) {
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-[#001F3F]">
      <div className="flex items-center justify-between px-4 py-4 sm:px-6">
        <p className="text-sm font-bold text-white">Votre QR Code est prêt</p>
        <button
          type="button"
          onClick={onClose}
          aria-label="Fermer"
          className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
        >
          <i className="ri-close-line text-xl" />
        </button>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center overflow-y-auto px-4 pb-8">
        <p className="mx-auto mb-3 max-w-sm rounded-2xl bg-white/10 px-4 py-3 text-center text-sm font-medium leading-relaxed text-white">
          Faites un appui long sur l&apos;image ci-dessous pour l&apos;enregistrer dans votre galerie.
        </p>
        <p className="mb-4 text-center text-xs text-white/60">
          L&apos;image contient votre QR code, en haute qualité.
        </p>

        <img
          src={imageUrl}
          alt="Votre QR Code"
          className="mx-auto block h-auto w-full max-w-[340px] rounded-2xl bg-white shadow-[0_20px_50px_-20px_rgba(0,0,0,0.8)]"
          style={{ WebkitTouchCallout: "default", touchAction: "auto" }}
        />

        <div className="mt-5 flex w-full max-w-[340px] flex-col gap-2">
          <p className="flex items-start gap-2 rounded-xl bg-white/5 px-3 py-2 text-xs leading-relaxed text-white/70">
            <i className="ri-cellphone-line mt-0.5" />
            Sur téléphone : appui long sur l&apos;image, puis « Enregistrer l&apos;image ».
          </p>
          <p className="flex items-start gap-2 rounded-xl bg-white/5 px-3 py-2 text-xs leading-relaxed text-white/70">
            <i className="ri-computer-line mt-0.5" />
            Sur ordinateur : clic droit sur l&apos;image, puis « Enregistrer l&apos;image sous… ».
          </p>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full max-w-[340px] cursor-pointer rounded-2xl bg-[#E60000] px-5 py-4 text-base font-bold text-white transition hover:bg-[#c90000] active:scale-[0.99] whitespace-nowrap"
        >
          Fermer
        </button>
      </div>
    </div>
  );
}