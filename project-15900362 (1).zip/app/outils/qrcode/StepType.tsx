'use client';

import { QR_TYPES } from "./lib/qrTypes";
import type { QrTypeId } from "./lib/qrTypes";

type Props = {
  onPick: (id: QrTypeId) => void;
};

export default function StepType({ onPick }: Props) {
  return (
    <section>
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#001F3F] text-lg font-bold text-white">
          1
        </span>
        <div className="min-w-0">
          <h2 className="text-xl font-bold tracking-tight text-[#001F3F] sm:text-2xl">
            Que voulez-vous partager ?
          </h2>
          <p className="text-sm text-slate-500">Touchez une seule image.</p>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {QR_TYPES.map((item) => {
          const isNew = item.id === "online";
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onPick(item.id)}
              className={`group relative flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 bg-white px-3 py-6 text-center shadow-[0_10px_24px_-20px_rgba(0,31,63,0.6)] transition hover:-translate-y-0.5 hover:shadow-[0_16px_30px_-20px_rgba(0,31,63,0.7)] active:scale-[0.98] ${
                isNew
                  ? "col-span-2 border-[#E60000]/40 hover:border-[#E60000] sm:col-span-3 sm:border-slate-200 sm:hover:border-[#001F3F]"
                  : "border-slate-200 hover:border-[#001F3F]"
              }`}
            >
              {isNew && (
                <span className="absolute right-2 top-2 rounded-full bg-[#E60000] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                  Nouveau
                </span>
              )}
              <span className="text-4xl leading-none sm:text-5xl">{item.emoji}</span>
              <span className="text-sm font-bold leading-tight text-[#001F3F]">
                {item.label}
              </span>
              <span className="text-[11px] leading-tight text-slate-400">{item.short}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}