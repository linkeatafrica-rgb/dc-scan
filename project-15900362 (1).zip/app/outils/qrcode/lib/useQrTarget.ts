'use client';

import { useMemo, useState } from "react";
import { buildTel, buildWhatsApp, ensureUrl } from "./qrTypes";
import type { QrTypeId } from "./qrTypes";

export type MediaMode = "upload" | "link";

export function useQrTarget() {
  const [type, setType] = useState<QrTypeId>("web");
  const [webUrl, setWebUrl] = useState("");
  const [paymentUrl, setPaymentUrl] = useState("");
  const [docUrl, setDocUrl] = useState("");
  const [phone, setPhone] = useState("");

  const [photoMode, setPhotoMode] = useState<MediaMode>("upload");
  const [photoName, setPhotoName] = useState("");
  const [photoHosted, setPhotoHosted] = useState("");
  const [photoDirect, setPhotoDirect] = useState("");

  const [fileMode, setFileMode] = useState<MediaMode>("upload");
  const [fileName, setFileName] = useState("");
  const [fileHosted, setFileHosted] = useState("");
  const [fileDirect, setFileDirect] = useState("");

  const value = useMemo(() => {
    if (type === "web") return ensureUrl(webUrl);
    if (type === "payment") return ensureUrl(paymentUrl);
    if (type === "online") return ensureUrl(docUrl);
    if (type === "whatsapp") return buildWhatsApp(phone);
    if (type === "phone") return buildTel(phone);
    if (type === "photo") return photoMode === "upload" ? photoHosted : ensureUrl(photoDirect);
    if (type === "file") return fileMode === "upload" ? fileHosted : ensureUrl(fileDirect);
    return "";
  }, [type, webUrl, paymentUrl, docUrl, phone, photoMode, photoHosted, photoDirect, fileMode, fileHosted, fileDirect]);

  const temporary =
    (type === "photo" && photoMode === "upload" && Boolean(photoHosted)) ||
    (type === "file" && fileMode === "upload" && Boolean(fileHosted));

  const reset = () => {
    setWebUrl("");
    setPaymentUrl("");
    setDocUrl("");
    setPhone("");
    setPhotoMode("upload");
    setPhotoName("");
    setPhotoHosted("");
    setPhotoDirect("");
    setFileMode("upload");
    setFileName("");
    setFileHosted("");
    setFileDirect("");
  };

  return {
    type,
    setType,
    webUrl,
    setWebUrl,
    paymentUrl,
    setPaymentUrl,
    docUrl,
    setDocUrl,
    phone,
    setPhone,
    photoMode,
    setPhotoMode,
    photoName,
    photoHosted,
    photoDirect,
    setPhotoDirect,
    setPhoto: (name: string, link: string) => {
      setPhotoName(name);
      setPhotoHosted(link);
    },
    clearPhoto: () => {
      setPhotoName("");
      setPhotoHosted("");
    },
    fileMode,
    setFileMode,
    fileName,
    fileHosted,
    fileDirect,
    setFileDirect,
    setFile: (name: string, link: string) => {
      setFileName(name);
      setFileHosted(link);
    },
    clearFile: () => {
      setFileName("");
      setFileHosted("");
    },
    temporary,
    reset,
    value,
  };
}