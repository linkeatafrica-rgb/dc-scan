export function hasQrContent(canvas: HTMLCanvasElement): boolean {
  const ctx = canvas.getContext("2d");
  if (!ctx || !canvas.width || !canvas.height) return false;
  try {
    const data = ctx.getImageData(0, Math.floor(canvas.height / 2), canvas.width, 1).data;
    let first = -1;
    let distinct = 0;
    for (let index = 0; index < data.length; index += 4) {
      const value = (data[index] << 16) | (data[index + 1] << 8) | data[index + 2];
      if (first === -1) {
        first = value;
      } else if (value !== first) {
        distinct += 1;
        if (distinct > 24) return true;
      }
    }
    return false;
  } catch {
    return false;
  }
}

export async function waitForQrCanvas(
  source: HTMLCanvasElement | null
): Promise<HTMLCanvasElement | null> {
  for (let attempt = 0; attempt < 16; attempt += 1) {
    if (source && source.width > 0 && hasQrContent(source)) return source;
    await new Promise((resolve) => window.setTimeout(resolve, 60));
  }
  return source;
}

export function pickReadyCanvas(
  primary: HTMLCanvasElement | null,
  fallback: HTMLCanvasElement | null
): HTMLCanvasElement | null {
  if (primary && primary.width > 0 && hasQrContent(primary)) return primary;
  if (fallback && fallback.width > 0 && hasQrContent(fallback)) return fallback;
  return null;
}

export function renderQrImage(source: HTMLCanvasElement, bgColor: string): string {
  const side = Math.max(source.width, source.height);
  const quiet = Math.round(side * 0.08);
  const canvas = document.createElement("canvas");
  canvas.width = side + quiet * 2;
  canvas.height = side + quiet * 2;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(source, quiet, quiet, side, side);
  try {
    return canvas.toDataURL("image/png");
  } catch {
    return "";
  }
}