export const MAX_FILE_SIZE = 5 * 1024 * 1024;

const UPLOAD_TIMEOUT = 45000;

export type UploadProgress = (percent: number) => void;

function postForm(url: string, body: FormData, onProgress?: UploadProgress): Promise<string> {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("POST", url, true);
    request.timeout = UPLOAD_TIMEOUT;

    request.upload.onprogress = (event) => {
      if (!onProgress || !event.lengthComputable) return;
      const percent = Math.round((event.loaded / event.total) * 100);
      onProgress(Math.min(99, Math.max(0, percent)));
    };

    request.onload = () => {
      if (request.status >= 200 && request.status < 300) {
        resolve(request.responseText);
      } else {
        reject(new Error("upload"));
      }
    };
    request.onerror = () => reject(new Error("upload"));
    request.ontimeout = () => reject(new Error("timeout"));
    request.onabort = () => reject(new Error("abort"));

    request.send(body);
  });
}

async function uploadToTmpfiles(file: File, onProgress?: UploadProgress): Promise<string> {
  const body = new FormData();
  body.append("file", file);
  const text = await postForm("https://tmpfiles.org/api/v1/upload", body, onProgress);
  const data = JSON.parse(text) as { data?: { url?: string } };
  const url = data?.data?.url;
  if (!url) throw new Error("tmpfiles");
  return url.replace("tmpfiles.org/", "tmpfiles.org/dl/");
}

async function uploadToLitterbox(file: File, onProgress?: UploadProgress): Promise<string> {
  const body = new FormData();
  body.append("reqtype", "fileupload");
  body.append("time", "1h");
  body.append("fileToUpload", file);
  const text = (await postForm(
    "https://litterbox.catbox.moe/resources/internals/api.php",
    body,
    onProgress
  )).trim();
  if (!text.startsWith("http")) throw new Error("litterbox");
  return text;
}

export async function uploadFileToHost(
  file: File,
  onProgress?: UploadProgress
): Promise<string> {
  try {
    return await uploadToTmpfiles(file, onProgress);
  } catch {
    onProgress?.(0);
    return await uploadToLitterbox(file, onProgress);
  }
}

export async function downloadHostedFile(link: string, fileName: string) {
  const response = await fetch(link);
  if (!response.ok) throw new Error("download");
  const blob = await response.blob();
  if (!blob.size) throw new Error("download");

  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = fileName || "mon-fichier";
  anchor.rel = "noopener";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
}