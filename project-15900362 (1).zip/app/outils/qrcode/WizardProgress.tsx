'use client';

const STEPS = [
  { number: 1, label: "Choisir" },
  { number: 2, label: "Écrire" },
  { number: 3, label: "Terminer" },
];

type Props = {
  step: number;
  onGoTo: (step: number) => void;
};

export default function WizardProgress({ step, onGoTo }: Props) {
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-3 shadow-[0_1px_2px_rgba(16,24,40,0.04)]">
      <div className="flex items-center gap-2">
        {STEPS.map((item, index) => {
          const done = step > item.number;
          const active = step === item.number;
          return (
            <div key={item.number} className="flex min-w-0 flex-1 items-center gap-2">
              <button
                type="button"
                onClick={() => onGoTo(item.number)}
                className={`flex min-w-0 flex-1 cursor-pointer items-center gap-2 rounded-xl px-2 py-2 transition ${
                  active ? "bg-[#001F3F] text-white" : "text-slate-600 hover:bg-gray-50"
                }`}
              >
                <span
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold ${
                    active
                      ? "bg-white text-[#001F3F]"
                      : done
                        ? "bg-[#E60000] text-white"
                        : "bg-slate-100 text-slate-400"
                  }`}
                >
                  {done ? <i className="ri-check-line text-base" /> : item.number}
                </span>
                <span
                  className={`truncate text-xs font-bold sm:text-sm ${
                    active ? "text-white" : done ? "text-[#001F3F]" : "text-slate-400"
                  }`}
                >
                  {item.label}
                </span>
              </button>
              {index < STEPS.length - 1 && (
                <span className="hidden h-0.5 w-4 shrink-0 rounded-full bg-slate-200 sm:block" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}