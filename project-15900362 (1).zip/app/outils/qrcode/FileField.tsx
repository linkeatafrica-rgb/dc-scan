'use client';

import { useRef, useState } from "react";
import {
  MAX_FILE_SIZE,
  downloadHostedFile,
  uploadFileToHost,
} from "./lib/uploadToHost";
import { compressImage } from "./lib/compressImage";
import type { ChangeEvent, DragEvent } from "react";

type Props = {
  kind: "photo" | "file";
  fileName: string;
  fileLink: string;
  onUploaded: (name: string, link: string) => void;
  onCleared: () => void;
};

const CONFIG = {
  photo: {
    accept: "image/png,image/jpeg,image/webp",
    formats: "Photo JPG ou PNG · 5 Mo max",
    emoji: "🖼️",
    idle: "Ajouter ma photo",
    change: "Changer la photo",
    empty: "Aucune photo sélectionnée",
    download: "Télécharger ma photo",
    open: "Ouvrir la photo",
    clear: "Retirer la photo",
    wrongType: "Choisissez une image (photo).",
  },
  file: {
    accept: "application/pdf,image/png,image/jpeg",
    formats: "PDF, JPG ou PNG · 5 Mo max",
    emoji: "📄",
    idle: "Ajouter mon fichier",
    change: "Changer le fichier",
    empty: "Aucun fichier sélectionné",
    download: "Télécharger mon fichier",
    open: "Ouvrir le fichier",
    clear: "Retirer le fichier",
    wrongType: "Choisissez un fichier PDF, JPG ou PNG.",
  },
} as const;

export default function FileField({
  kind,
  fileName,
  fileLink,
  onUploaded,
  onCleared,
}: Props) {
  const config = CONFIG[kind];
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  const [fetching, setFetching] = useState(false);
  const [fetchError, setFetchError] = useState("");

  const saveFile = async () => {
    if (!fileLink || fetching) return;
    setFetchError("");
    setFetching(true);
    try {
      await downloadHostedFile(fileLink, fileName);
    } catch {
      setFetchError(
        "Téléchargement direct impossible. Touchez « Ouvrir » puis enregistrez le fichier."
      );
    } finally {
      setFetching(false);
    }
  };

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    setError("");
    if (file.size > MAX_FILE_SIZE) {
      setError("Fichier trop lourd. 5 Mo maximum.");
      return;
    }
    const allowed =
      kind === "photo" ? file.type.startsWith("image/") : file.type.startsWith("image/") || file.type === "application/pdf";
    if (!allowed) {
      setError(config.wrongType);
      return;
    }
    setUploading(true);
    setProgress(0);
    try {
      const ready = await compressImage(file);
      const link = await uploadFileToHost(ready, setProgress);
      onUploaded(ready.name || file.name, link);
    } catch {
      setError(
        "Envoi impossible. Vérifiez votre connexion, ou utilisez l'onglet « Lien direct (URL) »."
      );
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  const onSelect = (event: ChangeEvent<HTMLInputElement>) => {
    void handleFile(event.target.files?.[0]);
    event.target.value = "";
  };

  const onDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    void handleFile(event.dataTransfer.files?.[0]);
  };

  return (
    <div>
      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`cursor-pointer rounded-2xl border-2 border-dashed px-5 py-8 text-center transition ${
          dragging
            ? "border-[#001F3F] bg-[#001F3F]/5"
            : "border-slate-300 bg-gray-50/60 hover:border-[#001F3F] hover:bg-white"
        }`}
      >
        <span className="text-4xl">
          {uploading ? <i className="ri-loader-4-line animate-spin text-[#001F3F]" /> : config.emoji}
        </span>
        <p className="mt-3 text-base font-bold text-[#001F3F]">
          {uploading
            ? progress > 0
              ? `Envoi en cours… ${progress}%`
              : "Préparation de l'envoi…"
            : fileName
              ? config.change
              : config.idle}
        </p>
        <p className="mt-1 text-xs text-slate-400">
          {uploading ? "Gardez cette page ouverte, cela peut prendre un peu de temps." : config.formats}
        </p>
        <input
          ref={inputRef}
          type="file"
          accept={config.accept}
          onChange={onSelect}
          className="hidden"
        />
      </div>

      {fileName && fileLink && (
        <div className="mt-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-3">
          <div className="flex items-center gap-3">
            <i className="ri-checkbox-circle-fill text-xl text-emerald-600" />
            <p className="min-w-0 flex-1 truncate text-sm font-medium text-emerald-800">
              {fileName}
            </p>
            <button
              type="button"
              onClick={onCleared}
              className="shrink-0 cursor-pointer rounded-lg p-1.5 text-emerald-700 transition hover:bg-white"
              aria-label={config.clear}
            >
              <i className="ri-delete-bin-line" />
            </button>
          </div>

          <button
            type="button"
            onClick={saveFile}
            disabled={fetching}
            className="mt-3 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-[#001F3F] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#00152b] disabled:cursor-wait disabled:opacity-80 whitespace-nowrap"
          >
            <i className={`${fetching ? "ri-loader-4-line animate-spin" : "ri-download-2-line"} text-base`} />
            {fetching ? "Téléchargement…" : config.download}
          </button>

          <a
            href={fileLink}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 flex items-center justify-center gap-1.5 text-xs font-medium text-emerald-700 underline whitespace-nowrap"
          >
            <i className="ri-external-link-line" />
            {config.open}
          </a>

          {fetchError && (
            <p className="mt-2 flex items-start gap-1.5 text-xs font-medium leading-relaxed text-[#E60000]">
              <i className="ri-error-warning-line mt-0.5 shrink-0" />
              {fetchError}
            </p>
          )}
        </div>
      )}

      {error && (
        <p className="mt-3 flex items-start gap-1.5 rounded-xl bg-red-50 px-3 py-2 text-xs font-medium text-[#E60000]">
          <i className="ri-error-warning-line mt-0.5" />
          {error}
        </p>
      )}

      {!fileName && (
        <p className="mt-2 text-xs text-slate-400">{config.empty}</p>
      )}
    </div>
  );
}