import type { Metadata } from "next";
import { Inter } from "next/font/google";
import QrStudio from "./QrStudio";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Créer un QR Code — Simple et gratuit",
  description:
    "Créez votre QR code en 3 étapes simples : WhatsApp, appel, site internet, photo ou paiement. Téléchargez-le en haute qualité.",
};

export default function QrCodeToolPage() {
  return (
    <div className={inter.className}>
      <QrStudio />
    </div>
  );
}