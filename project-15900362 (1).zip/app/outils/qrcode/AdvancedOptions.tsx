'use client';

import { useState } from "react";

type Props = {
  fgColor: string;
  bgColor: string;
  onFgChange: (color: string) => void;
  onBgChange: (color: string) => void;
};

const FG_PRESETS = ["#001F3F", "#000000", "#E60000", "#0F766E", "#4C1D95"];
const BG_PRESETS = ["#FFFFFF", "#F1F5F9", "#FEF2F2", "#FFFBEB"];

export default function AdvancedOptions({
  fgColor,
  bgColor,
  onFgChange,
  onBgChange,
}: Props) {
  const [open, setOpen] = useState(false);

  return (
    <div className="border-t border-slate-100 pt-3">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex w-full cursor-pointer items-center justify-center gap-1.5 text-xs font-medium text-slate-400 transition hover:text-[#001F3F] whitespace-nowrap"
      >
        <i className="ri-settings-3-line" />
        Options avancées
        <i className={open ? "ri-arrow-up-s-line" : "ri-arrow-down-s-line"} />
      </button>

      {open && (
        <div className="mt-3 grid grid-cols-1 gap-4 rounded-xl bg-gray-50 p-3 sm:grid-cols-2">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
              Couleur des points
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              {FG_PRESETS.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => onFgChange(color)}
                  style={{ backgroundColor: color }}
                  className={`h-7 w-7 cursor-pointer rounded-lg border transition ${
                    fgColor.toLowerCase() === color.toLowerCase()
                      ? "border-[#001F3F] ring-2 ring-[#001F3F]/20"
                      : "border-slate-200 hover:scale-105"
                  }`}
                  aria-label={`Couleur ${color}`}
                />
              ))}
            </div>
          </div>

          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
              Couleur du fond
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              {BG_PRESETS.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => onBgChange(color)}
                  style={{ backgroundColor: color }}
                  className={`h-7 w-7 cursor-pointer rounded-lg border transition ${
                    bgColor.toLowerCase() === color.toLowerCase()
                      ? "border-[#001F3F] ring-2 ring-[#001F3F]/20"
                      : "border-slate-200 hover:scale-105"
                  }`}
                  aria-label={`Fond ${color}`}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}