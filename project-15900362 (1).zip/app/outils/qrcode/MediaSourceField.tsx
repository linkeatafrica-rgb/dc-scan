'use client';

import LinkField from "./LinkField";
import FileField from "./FileField";
import type { MediaMode } from "./lib/useQrTarget";

type Props = {
  kind: "photo" | "file";
  mode: MediaMode;
  onModeChange: (mode: MediaMode) => void;
  directLink: string;
  onDirectLinkChange: (value: string) => void;
  fileName: string;
  fileLink: string;
  onUploaded: (name: string, link: string) => void;
  onCleared: () => void;
};

const LABELS = {
  photo: {
    upload: "Uploader une photo",
    link: "Lien direct (URL)",
    fieldLabel: "Lien direct de ma photo",
    placeholder: "https://i.ibb.co/xxxx/ma-photo.jpg",
    hint: "ImgBB, Google Drive (« lien direct »), Dropbox… Collez ici l'adresse de l'image.",
  },
  file: {
    upload: "Uploader un fichier",
    link: "Lien direct (URL)",
    fieldLabel: "Lien direct de mon fichier",
    placeholder: "https://drive.google.com/uc?export=download&id=…",
    hint: "ImgBB, Google Drive (« lien direct »), Dropbox… Collez ici l'adresse du fichier.",
  },
} as const;

export default function MediaSourceField({
  kind,
  mode,
  onModeChange,
  directLink,
  onDirectLinkChange,
  fileName,
  fileLink,
  onUploaded,
  onCleared,
}: Props) {
  const labels = LABELS[kind];

  const tabs: { id: MediaMode; label: string; icon: string }[] = [
    { id: "upload", label: labels.upload, icon: "ri-upload-cloud-line" },
    { id: "link", label: labels.link, icon: "ri-link" },
  ];

  return (
    <div>
      <div className="flex items-center gap-1 rounded-full border border-slate-200 bg-gray-50 px-1 py-1">
        {tabs.map((tab) => {
          const active = mode === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onModeChange(tab.id)}
              className={`flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-full px-2 py-2 text-xs font-bold transition whitespace-nowrap ${
                active
                  ? "bg-white text-[#001F3F] shadow-[0_2px_8px_-4px_rgba(0,31,63,0.5)]"
                  : "text-slate-400 hover:text-[#001F3F]"
              }`}
            >
              <i className={`${tab.icon} text-base`} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {mode === "upload" ? (
        <div className="mt-4">
          <p className="mb-3 flex items-start gap-1.5 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] font-medium leading-relaxed text-amber-800">
            <i className="ri-error-warning-line mt-0.5 shrink-0 text-sm" />
            <span>
              ⚠️ Le lien généré expirera dans 1 heure. Pour un usage permanent, utilisez l&apos;option Lien direct.
            </span>
          </p>
          <FileField
            kind={kind}
            fileName={fileName}
            fileLink={fileLink}
            onUploaded={onUploaded}
            onCleared={onCleared}
          />
        </div>
      ) : (
        <div className="mt-4">
          <LinkField
            id={`qr-${kind}-direct`}
            label={labels.fieldLabel}
            icon="ri-link"
            placeholder={labels.placeholder}
            hint={labels.hint}
            value={directLink}
            onChange={onDirectLinkChange}
          />
          <p className="mt-3 flex items-start gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-[11px] font-medium leading-relaxed text-emerald-800">
            <i className="ri-shield-check-line mt-0.5 shrink-0 text-sm" />
            <span>
              Lien permanent : votre QR code fonctionnera aussi longtemps que le lien reste en ligne.
            </span>
          </p>
        </div>
      )}
    </div>
  );
}