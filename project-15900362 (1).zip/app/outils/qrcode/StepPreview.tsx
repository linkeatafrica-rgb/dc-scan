'use client';

import { useRef, useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { pickReadyCanvas, renderQrImage, waitForQrCanvas } from "./lib/exportQr";
import SaveModal from "./SaveModal";

type Props = {
  value: string;
  fgColor: string;
  bgColor: string;
  temporary?: boolean;
  onModify: () => void;
  onRestart: () => void;
};

const PREVIEW_SIZE = 320;
const EXPORT_SIZE = 1600;
const QUIET_ZONE = 4;

export default function StepPreview({
  value,
  fgColor,
  bgColor,
  temporary,
  onModify,
  onRestart,
}: Props) {
  const exportRef = useRef<HTMLCanvasElement | null>(null);
  const previewRef = useRef<HTMLCanvasElement | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [exporting, setExporting] = useState(false);

  const openModal = async () => {
    if (busy) return;
    setBusy(true);
    setExporting(true);
    try {
      const highRes = await waitForQrCanvas(exportRef.current);
      const canvas = pickReadyCanvas(highRes, previewRef.current);
      if (!canvas) return;
      const url = renderQrImage(canvas, bgColor);
      if (url) setImageUrl(url);
    } catch {
      /* rien ne casse */
    } finally {
      setBusy(false);
      setExporting(false);
    }
  };

  return (
    <section>
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#E60000] text-lg font-bold text-white">
          3
        </span>
        <div className="min-w-0">
          <h2 className="text-xl font-bold tracking-tight text-[#001F3F] sm:text-2xl">
            Votre QR Code est prêt !
          </h2>
          <p className="text-sm text-slate-500">Enregistrez-le et imprimez-le.</p>
        </div>
      </div>

      <div className="mt-5 rounded-2xl border border-slate-200/80 bg-white p-4 text-center shadow-[0_1px_2px_rgba(16,24,40,0.04),0_18px_40px_-26px_rgba(0,31,63,0.45)] sm:p-5">
        <div className="mx-auto flex items-center justify-center rounded-2xl bg-[#F4F6FA] p-3">
          <div className="w-full max-w-[260px] rounded-xl bg-white p-2.5 shadow-[0_12px_30px_-14px_rgba(0,31,63,0.5)]" style={{ backgroundColor: bgColor }}>
            <QRCodeCanvas
              ref={previewRef}
              value={value}
              size={PREVIEW_SIZE}
              level="Q"
              bgColor={bgColor}
              fgColor={fgColor}
              marginSize={QUIET_ZONE}
              className="h-auto w-full"
            />
          </div>
        </div>

        <p className="mt-3 text-xs text-slate-400">
          Testez-le avec l&apos;appareil photo de votre téléphone.
        </p>

        <button
          type="button"
          onClick={openModal}
          disabled={busy}
          className="mt-4 flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl bg-[#E60000] px-5 py-4 text-base font-bold text-white shadow-[0_14px_28px_-16px_rgba(230,0,0,0.9)] transition hover:bg-[#c90000] active:scale-[0.99] disabled:cursor-wait disabled:opacity-80 whitespace-nowrap"
        >
          <i className={`${busy ? "ri-loader-4-line animate-spin" : "ri-download-2-line"} text-lg`} />
          {busy ? "Préparation…" : "Télécharger mon QR Code"}
        </button>

        {temporary && (
          <p className="mt-3 flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-left text-xs font-medium leading-relaxed text-amber-800">
            <i className="ri-time-line mt-0.5 shrink-0" />
            <span>
              Attention : ce lien temporaire expirera dans 1 heure. Pour un QR code permanent, modifiez-le et collez un lien direct.
            </span>
          </p>
        )}

        <div className="mt-3 flex items-center justify-center gap-4">
          <button
            type="button"
            onClick={onModify}
            className="cursor-pointer py-1 text-sm font-medium text-slate-400 transition hover:text-[#001F3F] whitespace-nowrap"
          >
            <i className="ri-edit-line mr-1" />
            Modifier
          </button>
          <span className="h-4 w-px bg-slate-200" />
          <button
            type="button"
            onClick={onRestart}
            className="cursor-pointer py-1 text-sm font-medium text-slate-400 transition hover:text-[#001F3F] whitespace-nowrap"
          >
            <i className="ri-add-line mr-1" />
            Nouveau QR code
          </button>
        </div>
      </div>

      {exporting && (
        <div className="pointer-events-none fixed -left-[9999px] top-0 opacity-0" aria-hidden>
          <QRCodeCanvas
            ref={exportRef}
            value={value}
            size={EXPORT_SIZE}
            level="Q"
            bgColor={bgColor}
            fgColor={fgColor}
            marginSize={0}
          />
        </div>
      )}

      {imageUrl && <SaveModal imageUrl={imageUrl} onClose={() => setImageUrl(null)} />}
    </section>
  );
}