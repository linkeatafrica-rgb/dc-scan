'use client';

import { useState } from "react";
import ToolHeader from "./ToolHeader";
import WizardProgress from "./WizardProgress";
import StepType from "./StepType";
import StepInfo from "./StepInfo";
import StepPreview from "./StepPreview";
import { useQrTarget } from "./lib/useQrTarget";

export default function QrStudio() {
  const target = useQrTarget();
  const [step, setStep] = useState(1);
  const [fgColor, setFgColor] = useState("#001F3F");
  const [bgColor, setBgColor] = useState("#FFFFFF");
  const [error, setError] = useState("");

  const pickType = (id: typeof target.type) => {
    target.setType(id);
    setError("");
    setStep(2);
  };

  const create = () => {
    if (!target.value.trim()) {
      const media =
        target.type === "photo"
          ? target.photoMode
          : target.type === "file"
            ? target.fileMode
            : null;
      if (media === "link") {
        setError("Collez le lien direct du fichier, ou choisissez « Uploader ».");
      } else if (media === "upload") {
        setError("Ajoutez d'abord votre fichier, ou collez un lien direct.");
      } else {
        setError("Ajoutez l'information, puis touchez le bouton rouge.");
      }
      return;
    }
    setError("");
    setStep(3);
  };

  const restart = () => {
    target.reset();
    setError("");
    setStep(1);
  };

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 text-slate-900">
      <ToolHeader />

      <main className="mx-auto w-full max-w-[780px] flex-1 px-4 pb-12 pt-6 sm:px-6 sm:pt-9">
        <div className="text-center">
          <h1 className="text-2xl font-bold tracking-tight text-[#001F3F] sm:text-[32px]">
            Créez votre QR Code
          </h1>
          <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-500">
            3 étapes simples. Pas besoin d&apos;ordinateur.
          </p>
        </div>

        <div className="mt-5">
          <WizardProgress step={step} onGoTo={(next) => (next < step ? setStep(next) : null)} />
        </div>

        <div className="mt-6">
          {step === 1 && <StepType onPick={pickType} />}

          {step === 2 && (
            <StepInfo
              target={target}
              fgColor={fgColor}
              bgColor={bgColor}
              onFgChange={setFgColor}
              onBgChange={setBgColor}
              error={error}
              onBack={() => {
                setError("");
                setStep(1);
              }}
              onCreate={create}
            />
          )}

          {step === 3 && (
            <StepPreview
              value={target.value}
              fgColor={fgColor}
              bgColor={bgColor}
              temporary={target.temporary}
              onModify={() => setStep(2)}
              onRestart={restart}
            />
          )}
        </div>

        <div className="mt-8 grid grid-cols-1 gap-2 sm:grid-cols-3">
          {[
            { emoji: "✅", text: "Se scanne avec tous les téléphones" },
            { emoji: "📥", text: "Image nette, prête à imprimer" },
            { emoji: "🔒", text: "Gratuit, sans compte" },
          ].map((item) => (
            <div
              key={item.text}
              className="flex items-center gap-2 rounded-xl border border-slate-200/80 bg-white px-3 py-3"
            >
              <span className="text-base">{item.emoji}</span>
              <span className="text-xs font-medium leading-snug text-slate-500">
                {item.text}
              </span>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}