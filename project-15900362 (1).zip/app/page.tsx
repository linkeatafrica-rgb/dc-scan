import HomeHeader from "../components/home/HomeHeader";
import HeroSection from "../components/home/HeroSection";
import BenefitsSection from "../components/home/BenefitsSection";
import StepsSection from "../components/home/StepsSection";
import CtaBand from "../components/home/CtaBand";
import HomeFooter from "../components/home/HomeFooter";

export const metadata = {
  title: "DC Scan — Générateur de QR codes professionnels",
  description:
    "Créez des QR codes haute définition, sécurisés et prêts à imprimer pour votre entreprise. Gratuit, sans compte.",
};

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-[#020A14]">
      <HomeHeader />
      <main className="flex-1">
        <HeroSection />
        <BenefitsSection />
        <StepsSection />
        <CtaBand />
      </main>
      <HomeFooter />
    </div>
  );
}